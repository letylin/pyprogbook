#E_7_15: 上網路抓取股價資料
from pandas_datareader import data as pdr
import fix_yahoo_finance as yf
import pandas as pd
import datetime
#下載資料起始日與股票代號
yf.pdr_override() # <== that's all it takes :-)
start = datetime.datetime(2016,1,1)
end = datetime.datetime(2018,3,1)
df = pdr.get_data_yahoo('2330.tw',start,end)
#日股價資料寫入excel檔
writer=pd.ExcelWriter('./file/2330.xlsx')
df = pdr.get_data_yahoo(["2330.tw"], start, end)
df.to_excel(writer,'Sheet1')
writer.save()