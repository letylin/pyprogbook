#E_6_7.py 功能: 位置參數的使用範例
def polyequ(x):
#polyequ: 計算(x**2)+(4*x)+6的結果    
    return (x**2)+(4*x)+6
result=polyequ(4)
print('呼叫函數(x**2)+(4*x)+6 =', result)


#sample=4    
#result=polyequ(sample)