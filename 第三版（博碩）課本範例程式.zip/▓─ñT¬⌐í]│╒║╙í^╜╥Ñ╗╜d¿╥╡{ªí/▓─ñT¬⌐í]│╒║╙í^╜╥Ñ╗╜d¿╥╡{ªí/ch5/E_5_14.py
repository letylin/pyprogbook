# E_5_14 功能: 使用arange函數產生浮點數。
import numpy as np
for i in np.arange(0, 0.3, 0.1):
    print(i)
