#E_8_10\formats\fontname.py
def name():
    return('This is E_8_10\\formats\\fontname.py') 