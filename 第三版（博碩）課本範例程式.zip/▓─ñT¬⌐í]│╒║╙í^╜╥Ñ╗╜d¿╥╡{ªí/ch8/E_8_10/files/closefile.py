#E_8_10\files\closefile.py
def closef():
    return('This is E_8_10\\files\\closefile.py') 