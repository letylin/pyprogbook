#E_5_6 功能: 計算1累加到5的總和
sumi=0
n=5
for i in range(1,n+1):
    sumi=sumi+i
    print(sumi)
print('sumi =',sumi)